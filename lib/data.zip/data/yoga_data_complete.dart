import '../models/yoga_pose.dart';
import '../models/yoga_session.dart';

class YogaDataComplete {
  // ============================================
  // BEGINNER LEVEL - Chair Yoga
  // ============================================

  static final List<YogaPose> beginnerWarmupSitting = [
    YogaPose(
      name: 'Head, Neck and Shoulders Stretch',
      description: 'Comprehensive neck and shoulder stretches to release tension',
      imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=500',
      durationSeconds: 180,
      modifications: ['Move slowly', 'Stop if dizzy', 'Use chair back for support'],
      instructions: '''1. Tilt head up, hold for 5 breaths. Tilt down, chin to chest, hold for 5-10 breaths. Repeat 3 times.
2. Turn head right, chin to right shoulder, hold 5 breaths. Turn left, hold 5-10 breaths. Repeat 3 times.
3. Drop right ear to right shoulder, right palm on head. Bend left arm behind back. Hold 5 breaths. Repeat other side.''',
      category: 'warmup',
    ),
    YogaPose(
      name: 'Straight Arms Rotation',
      description: 'Rotate arms with fists to warm up shoulders',
      imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=500',
      durationSeconds: 60,
      modifications: ['Keep elbows straight', 'Smooth movements'],
      instructions: 'Make fists with thumbs inside. Rotate arms without bending elbows. 10 times in one direction, then 10 times in opposite direction.',
      category: 'warmup',
    ),
    YogaPose(
      name: 'Bent Arm Rotation',
      description: 'Shoulder mobility with bent arms',
      imageUrl: 'https://images.unsplash.com/photo-1588286840104-8957b019727f?w=500',
      durationSeconds: 60,
      modifications: ['Keep fingers on shoulders', 'Slow controlled movement'],
      instructions: 'Fingers on shoulders. Touch elbows in front, lift elbows behind head, touch wrists behind head. Roll forward and touch elbows. 10 times forward, 10 times backward.',
      category: 'warmup',
    ),
    YogaPose(
      name: 'Shoulders Lateral Stretch',
      description: 'Side body stretch while seated',
      imageUrl: 'https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=500',
      durationSeconds: 120,
      modifications: ['Keep buttock down', 'Face forward'],
      instructions: 'Lift arms. Drop right arm to chair seat, stretch left arm overhead. Feel left side stretch. Face forward. Hold 5-10 breaths. Repeat 3 times each side.',
      category: 'warmup',
    ),
    YogaPose(
      name: 'Shoulders and Torso Twist',
      description: 'Gentle spinal twist for detoxification',
      imageUrl: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500',
      durationSeconds: 120,
      modifications: ['Keep hips stable', 'Level shoulders'],
      instructions: 'Lift and straighten arms. Turn torso right, hold chair rest to deepen twist. Keep hips stable and shoulders level. Hold 5-10 breaths. Repeat 3 times each side.',
      category: 'warmup',
    ),
    YogaPose(
      name: 'Leg Raise (Bent)',
      description: 'Strengthen core and legs',
      imageUrl: 'https://images.unsplash.com/photo-1603988363607-e1e4a66962c6?w=500',
      durationSeconds: 90,
      modifications: ['Use hand support if needed', 'Keep back straight'],
      instructions: 'Lift right leg high without hand support, back straight. Use chair back for support if needed. Hold as long as possible, release with control. Repeat left leg.',
      category: 'warmup',
    ),
    YogaPose(
      name: 'Leg Raise (Straight)',
      description: 'Advanced leg strengthening',
      imageUrl: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=500',
      durationSeconds: 90,
      modifications: ['Progress from bent knee', 'Hold chair if needed'],
      instructions: 'Lift right leg and straighten without hand support. Back remains straight. Hold as long as possible, release with control. Repeat left leg.',
      category: 'warmup',
    ),
    YogaPose(
      name: 'Goddess Pose (Shoulders and Torso Twist)',
      description: 'Wide-legged seated stretch',
      imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=500',
      durationSeconds: 120,
      modifications: ['Align knees with toes', 'Keep hips stable'],
      instructions: 'Widen knees to sides, toes point same direction as knees. Palms on thighs, stretch torso right by straightening left arm. Feel left side stretch. Hold 5-10 breaths each side.',
      category: 'warmup',
    ),
    YogaPose(
      name: 'Goddess Pose (Leg Stretch)',
      description: 'Leg strengthening in goddess position',
      imageUrl: 'https://images.unsplash.com/photo-1599447292326-e6daae7ae9cb?w=500',
      durationSeconds: 120,
      modifications: ['Use chair for balance', 'Keep torso upright'],
      instructions: 'Widen knees to sides, align toes with knees. Lift thighs from chair using leg strength. Upper body perpendicular to ground. Hold 5-10 breaths. Repeat 3 times.',
      category: 'warmup',
    ),
  ];

  static final List<YogaPose> beginnerMainStanding = [
    YogaPose(
      name: 'Back and Chest Stretch',
      description: 'Full body stretch forming L-shape',
      imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=500',
      durationSeconds: 120,
      modifications: ['Keep arms and legs straight', 'Engage abdomen'],
      instructions: 'Face chair rest. Hold top of chair. Feet hip-width apart. Upper body parallel with ground. Hips over feet forming horizontal "L". Arms and legs straight. Hold 5-10 breaths. Repeat 3 times.',
      category: 'main',
    ),
    YogaPose(
      name: 'Standing Crunch',
      description: 'Dynamic leg movement with core engagement',
      imageUrl: 'https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=500',
      durationSeconds: 150,
      modifications: ['Not for pregnant women', 'Control the movement'],
      instructions: 'Face chair rest, hold top. Feet together. Upper body parallel with ground forming "L". With inhalation straighten right leg back, with exhalation crunch right knee to chest. Repeat 5-10 times each leg.',
      category: 'main',
    ),
    YogaPose(
      name: 'Warrior 3',
      description: 'Balance and strength pose',
      imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=500',
      durationSeconds: 120,
      modifications: ['Keep one hand on chair', 'Maintain straight line'],
      instructions: 'Face chair, hold top. Feet together. Form "L" shape. Lift one hand off chair. Hold 5-10 breaths. Release. Repeat other hand. Change legs.',
      category: 'main',
    ),
    YogaPose(
      name: 'Warrior 1',
      description: 'Powerful standing pose with arm reach',
      imageUrl: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=500',
      durationSeconds: 120,
      modifications: ['Square hips', 'Tuck tailbone'],
      instructions: 'Sit across chair. Right leg bent, left leg straight. Right toes at 12 o\'clock, left toes at 11 o\'clock. Square hips. Arms up straight. Look at palms. Hold 5-10 breaths. Repeat 3 times each side.',
      category: 'main',
    ),
    YogaPose(
      name: 'Warrior 2',
      description: 'Side-facing warrior pose',
      imageUrl: 'https://images.unsplash.com/photo-1599447292326-e6daae7ae9cb?w=500',
      durationSeconds: 120,
      modifications: ['Align knee with toes', 'Keep shoulders level'],
      instructions: 'From Warrior 1, turn left toes to 3 o\'clock while right toes stay at 12 o\'clock. Align right knee with toes. Tuck tailbone. Look at right hand. Hold 5-10 breaths.',
      category: 'main',
    ),
    YogaPose(
      name: 'Triangle Pose',
      description: 'Deep side body stretch',
      imageUrl: 'https://images.unsplash.com/photo-1588286840104-8957b019727f?w=500',
      durationSeconds: 120,
      modifications: ['Keep hips forward', 'Use block if needed'],
      instructions: 'From Warrior 2, straighten bent leg. Stretch arms right, lower right palm along ankle. Left arm stretches up. Hips forward. Look at top palm. Hold 5-10 breaths each side.',
      category: 'main',
    ),
    YogaPose(
      name: 'Reverse Warrior 2',
      description: 'Backbend warrior variation',
      imageUrl: 'https://images.unsplash.com/photo-1603988363607-e1e4a66962c6?w=500',
      durationSeconds: 120,
      modifications: ['Keep front knee bent', 'Choose gaze direction'],
      instructions: 'From Warrior 2, stretch right arm overhead, palm down. Left arm along left leg. Look at right or left hand. Hold 5-10 breaths.',
      category: 'main',
    ),
    YogaPose(
      name: 'Side Angle Pose',
      description: 'Extended side angle stretch',
      imageUrl: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500',
      durationSeconds: 120,
      modifications: ['Use block for support', 'Tuck tailbone'],
      instructions: 'From Warrior 2, lower palm inside right foot (use block if needed). Stretch left arm overhead, palm down. Look up at left hand. Tuck tailbone. Hold 5-10 breaths each side.',
      category: 'main',
    ),
  ];

  static final List<YogaPose> beginnerCooldown = [
    YogaPose(
      name: 'Gentle Breathing',
      description: 'Calm the nervous system',
      imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=500',
      durationSeconds: 180,
      modifications: ['Sit or lie comfortably', 'Close eyes'],
      instructions: 'Sit comfortably in chair or lie down. Close eyes. Breathe naturally through nose. Focus on breath entering and leaving body. Relax completely.',
      category: 'cooldown',
    ),
  ];

  // ============================================
  // INTERMEDIATE LEVEL - Hatha Yoga
  // ============================================

  static final List<YogaPose> intermediateMain = [
    YogaPose(
      name: 'Downward Dog',
      description: 'Inverted V-shape pose for full body stretch',
      imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=500',
      durationSeconds: 120,
      modifications: ['Bend knees if tight hamstrings', 'Press hands firmly'],
      instructions: 'Feet hips-width apart. Hands shoulder-width apart. Push hips back forming inverted "V". Elongate outer arms until you feel suction in core. Hold 5-10 breaths. Repeat 3 times.',
      category: 'main',
    ),
    YogaPose(
      name: 'Plank',
      description: 'Full body strengthening pose',
      imageUrl: 'https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=500',
      durationSeconds: 90,
      modifications: ['Knees down for easier variation', 'Feet together for challenge'],
      instructions: 'Hands under shoulders. Feet hips-width on toes. Head to feet forms straight line. Engage core by sucking belly inward. Hold 5-10 breaths. Repeat 3 times.',
      category: 'main',
    ),
    YogaPose(
      name: 'Eight-Point Pose (Ashtangasana)',
      description: 'Caterpillar pose for strength',
      imageUrl: 'https://images.unsplash.com/photo-1588286840104-8957b019727f?w=500',
      durationSeconds: 90,
      modifications: ['Not for pregnant women', 'Lower slowly with control'],
      instructions: 'From lowered knees tabletop, shift torso forward. Lower chest to mat with control. Chin, chest, palms, knees and toes grounded. Belly lifted. Squeeze elbows to torso. Hold 5-10 breaths. Repeat 3 times.',
      category: 'main',
    ),
    YogaPose(
      name: 'Baby Cobra',
      description: 'Gentle backbend',
      imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=500',
      durationSeconds: 90,
      modifications: ['Lift palms for challenge', 'Keep shoulders down'],
      instructions: 'From Eight-point pose, shift forward. Whole body grounded except chest. Toes pointed. Press lower body and feet to lift chest. Hold 5-10 breaths. Repeat 3 times.',
      category: 'main',
    ),
    YogaPose(
      name: 'Full Cobra',
      description: 'Deep backbend chest opener',
      imageUrl: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=500',
      durationSeconds: 90,
      modifications: ['Keep shoulders down', 'Engage legs'],
      instructions: 'From Baby Cobra, push up and straighten elbows. Keep shoulders down, chest up. Hold 5-10 breaths. Repeat 3 times.',
      category: 'main',
    ),
  ];

  // ============================================
  // ADVANCED LEVEL - Sun Salutation Flow
  // ============================================

  static final List<YogaPose> advancedFlow = [
    YogaPose(
      name: 'Sun Salutation Flow',
      description: 'Dynamic flow sequence - one breath, one movement',
      imageUrl: 'https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=500',
      durationSeconds: 300,
      modifications: ['Rest in child\'s pose when needed', 'Build up to 10 rounds gradually'],
      instructions: '''Flow sequence combining intermediate poses:
1. Downward Dog (inhale)
2. Plank (exhale)
3. Eight-Point Pose (inhale)
4. Baby Cobra (exhale)
5. Full Cobra (inhale)
6. Downward Dog (exhale)

Repeat 5-10 rounds or to your ability. One breath, one movement. Smooth transitions.''',
      category: 'main',
    ),
  ];

  // ============================================
  // SESSIONS
  // ============================================

  static final List<YogaSession> beginnerSessions = [
    YogaSession(
      id: 'beginner_1',
      title: 'Gentle Chair Yoga',
      level: 'Beginner',
      description: 'Complete chair yoga session suitable for all levels. Focus on gentle movements with chair support.',
      totalDurationMinutes: 35,
      warmupPoses: beginnerWarmupSitting,
      mainPoses: beginnerMainStanding,
      cooldownPoses: beginnerCooldown,
    ),
    YogaSession(
      id: 'beginner_2',
      title: 'Morning Mobility',
      level: 'Beginner',
      description: 'Wake up your body with gentle seated stretches. Perfect for starting your day.',
      totalDurationMinutes: 20,
      warmupPoses: beginnerWarmupSitting.take(5).toList(),
      mainPoses: beginnerMainStanding.take(4).toList(),
      cooldownPoses: beginnerCooldown,
    ),
    YogaSession(
      id: 'beginner_3',
      title: 'Warrior Series',
      level: 'Beginner',
      description: 'Build strength and confidence with warrior poses using chair support.',
      totalDurationMinutes: 25,
      warmupPoses: beginnerWarmupSitting.take(4).toList(),
      mainPoses: beginnerMainStanding.sublist(3, 8).toList(),
      cooldownPoses: beginnerCooldown,
    ),
  ];

  static final List<YogaSession> intermediateSessions = [
    YogaSession(
      id: 'intermediate_1',
      title: 'Hatha Fundamentals',
      level: 'Intermediate',
      description: 'Classic hatha yoga sequence on the mat. Build strength and flexibility.',
      totalDurationMinutes: 30,
      warmupPoses: [],
      mainPoses: intermediateMain,
      cooldownPoses: beginnerCooldown,
    ),
    YogaSession(
      id: 'intermediate_2',
      title: 'Core Strength Builder',
      level: 'Intermediate',
      description: 'Focus on plank and core strengthening poses.',
      totalDurationMinutes: 20,
      warmupPoses: [],
      mainPoses: intermediateMain.take(3).toList(),
      cooldownPoses: beginnerCooldown,
    ),
    YogaSession(
      id: 'intermediate_3',
      title: 'Backbend Flow',
      level: 'Intermediate',
      description: 'Strengthen spine with cobra variations.',
      totalDurationMinutes: 25,
      warmupPoses: [],
      mainPoses: intermediateMain.sublist(2).toList(),
      cooldownPoses: beginnerCooldown,
    ),
  ];

  static final List<YogaSession> advancedSessions = [
    YogaSession(
      id: 'advanced_1',
      title: 'Sun Salutation Flow',
      level: 'Advanced',
      description: 'Dynamic flow practice. One breath, one movement. Build stamina and focus.',
      totalDurationMinutes: 15,
      warmupPoses: [],
      mainPoses: advancedFlow,
      cooldownPoses: beginnerCooldown,
    ),
    YogaSession(
      id: 'advanced_2',
      title: 'Extended Flow Practice',
      level: 'Advanced',
      description: 'Longer sun salutation practice for experienced practitioners.',
      totalDurationMinutes: 25,
      warmupPoses: [],
      mainPoses: advancedFlow,
      cooldownPoses: beginnerCooldown,
    ),
  ];
}
