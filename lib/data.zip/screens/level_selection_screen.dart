import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/user_progress.dart';
import '../services/progress_service.dart';
import 'beginner_sessions_screen.dart';
import 'intermediate_sessions_screen.dart';
import 'advanced_sessions_screen.dart';

class LevelSelectionScreenEnhanced extends StatefulWidget {
  const LevelSelectionScreenEnhanced({super.key});

  @override
  State<LevelSelectionScreenEnhanced> createState() => _LevelSelectionScreenEnhancedState();
}

class _LevelSelectionScreenEnhancedState extends State<LevelSelectionScreenEnhanced> {
  final ProgressService _progressService = ProgressService();
  UserProgress? _userProgress;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadUserProgress();
  }

  Future<void> _loadUserProgress() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('User not authenticated');

      final progress = await _progressService.getUserProgress(userId);

      setState(() {
        _userProgress = progress;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  void _showUnlockCelebration(String level) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Container(
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFE3F8F5), Color(0xFFD0F7F0)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                '🎉',
                style: TextStyle(fontSize: 80),
              ),
              const SizedBox(height: 16),
              const Text(
                'Congratulations!',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF40E0D0),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'You\'ve unlocked $level Level!',
                style: const TextStyle(
                  fontSize: 20,
                  color: Colors.black87,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              const Text(
                'Keep up the amazing work on your yoga journey! 🧘‍♀️',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  _loadUserProgress();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF40E0D0),
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: const Text(
                  'Continue',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Container(
        color: const Color(0xFFFAFAFA),
        child: const Center(
          child: CircularProgressIndicator(
            color: Color(0xFF40E0D0),
          ),
        ),
      );
    }

    if (_error != null) {
      return Container(
        color: const Color(0xFFFAFAFA),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 64, color: Colors.red),
              const SizedBox(height: 16),
              Text('Error: $_error'),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _loadUserProgress,
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      color: const Color(0xFFFAFAFA),
      child: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12),

                // Header
                const Text(
                  'Choose Your',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const Text(
                  'Practice Level',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF40E0D0),
                  ),
                ),

                const SizedBox(height: 12),

                Text(
                  'Progress through levels by completing sessions',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[600],
                    height: 1.5,
                  ),
                ),

                const SizedBox(height: 36),

                // Beginner Card (Always Unlocked)
                _buildLevelCard(
                  context,
                  title: 'Beginner',
                  subtitle: 'Chair yoga for gentle practice',
                  description: 'Perfect for those just starting their yoga journey with gentle, guided sessions.',
                  imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=600',
                  color: const Color(0xFF40E0D0),
                  features: ['Chair support', 'Gentle pace', 'Safety first'],
                  isLocked: false,
                  sessionsCompleted: _userProgress?.beginnerSessionsCompleted ?? 0,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const BeginnerSessionsScreen(),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 20),

                // Intermediate Card
                _buildLevelCard(
                  context,
                  title: 'Intermediate',
                  subtitle: 'Hatha yoga on the mat',
                  description: 'Build on your foundation with more challenging sequences and longer holds.',
                  imageUrl: 'https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=600',
                  color: const Color(0xFF35C9BA),
                  features: ['Build strength', 'Flexibility', 'Balance'],
                  isLocked: !(_userProgress?.intermediateUnlocked ?? false),
                  sessionsCompleted: _userProgress?.intermediateSessionsCompleted ?? 0,
                  progress: _userProgress?.progressToIntermediate ?? 0.0,
                  requiredSessions: UserProgress.sessionsRequiredForIntermediate,
                  currentLevelSessions: _userProgress?.beginnerSessionsCompleted ?? 0,
                  onTap: () {
                    if (_userProgress?.intermediateUnlocked ?? false) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const IntermediateSessionsScreen(),
                        ),
                      );
                    } else {
                      _showLockedDialog(
                        'Intermediate',
                        UserProgress.sessionsRequiredForIntermediate,
                        _userProgress?.beginnerSessionsCompleted ?? 0,
                      );
                    }
                  },
                ),

                const SizedBox(height: 20),

                // Advanced Card
                _buildLevelCard(
                  context,
                  title: 'Advanced',
                  subtitle: 'Dynamic sun salutation flow',
                  description: 'Challenge yourself with flowing sequences and advanced breathing techniques.',
                  imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=600',
                  color: const Color(0xFF2AB5A5),
                  features: ['Deep practice', 'Flow sequence', 'Mastery'],
                  isLocked: !(_userProgress?.advancedUnlocked ?? false),
                  sessionsCompleted: _userProgress?.advancedSessionsCompleted ?? 0,
                  progress: _userProgress?.progressToAdvanced ?? 0.0,
                  requiredSessions: UserProgress.sessionsRequiredForAdvanced,
                  currentLevelSessions: _userProgress?.intermediateSessionsCompleted ?? 0,
                  needsIntermediate: !(_userProgress?.intermediateUnlocked ?? false),
                  onTap: () {
                    if (_userProgress?.advancedUnlocked ?? false) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const AdvancedSessionsScreen(),
                        ),
                      );
                    } else {
                      _showLockedDialog(
                        'Advanced',
                        UserProgress.sessionsRequiredForAdvanced,
                        _userProgress?.intermediateSessionsCompleted ?? 0,
                        needsIntermediate: !(_userProgress?.intermediateUnlocked ?? false),
                      );
                    }
                  },
                ),

                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showLockedDialog(String level, int required, int current, {bool needsIntermediate = false}) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(Icons.lock, color: Color(0xFF40E0D0), size: 28),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                '$level Level Locked',
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (needsIntermediate)
              const Text(
                'You need to unlock Intermediate level first!',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black87,
                ),
              )
            else ...[
              Text(
                'Complete ${required - current} more ${level == 'Advanced' ? 'Intermediate' : 'Beginner'} session${required - current == 1 ? '' : 's'} to unlock this level.',
                style: const TextStyle(
                  fontSize: 16,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 16),
              LinearProgressIndicator(
                value: current / required,
                backgroundColor: Colors.grey[300],
                valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF40E0D0)),
                minHeight: 8,
              ),
              const SizedBox(height: 8),
              Text(
                '$current / $required sessions completed',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Got it',
              style: TextStyle(
                color: Color(0xFF40E0D0),
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLevelCard(
      BuildContext context, {
        required String title,
        required String subtitle,
        required String description,
        required String imageUrl,
        required Color color,
        required List<String> features,
        required VoidCallback onTap,
        bool isLocked = false,
        int sessionsCompleted = 0,
        double progress = 0.0,
        int? requiredSessions,
        int? currentLevelSessions,
        bool needsIntermediate = false,
      }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 240,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: isLocked
                  ? Colors.grey.withOpacity(0.2)
                  : color.withOpacity(0.2),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          children: [
            // Background Image
            ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: NetworkImage(imageUrl),
                    fit: BoxFit.cover,
                    colorFilter: isLocked
                        ? ColorFilter.mode(
                      Colors.grey.withOpacity(0.5),
                      BlendMode.saturation,
                    )
                        : null,
                  ),
                ),
              ),
            ),

            // Gradient Overlay
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(isLocked ? 0.5 : 0.3),
                    Colors.black.withOpacity(0.8),
                  ],
                ),
              ),
            ),

            // Lock Overlay
            if (isLocked)
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  color: Colors.black.withOpacity(0.3),
                ),
                child: const Center(
                  child: Icon(
                    Icons.lock,
                    size: 64,
                    color: Colors.white,
                  ),
                ),
              ),

            // Content
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Badge
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: isLocked ? Colors.grey : color,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          title.toUpperCase(),
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                      if (!isLocked && sessionsCompleted > 0)
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.9),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              '$sessionsCompleted completed',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: color,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),

                  const Spacer(),

                  // Title
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),

                  const SizedBox(height: 6),

                  // Subtitle
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 15,
                      color: Colors.white70,
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Progress bar for locked levels
                  if (isLocked && requiredSessions != null && currentLevelSessions != null && !needsIntermediate) ...[
                    Container(
                      height: 6,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(3),
                      ),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: progress,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '$currentLevelSessions / $requiredSessions to unlock',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ] else if (!isLocked)
                  // Features for unlocked levels
                    Row(
                      children: features.map((feature) {
                        return Container(
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.3),
                            ),
                          ),
                          child: Text(
                            feature,
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                ],
              ),
            ),

            // Action icon
            Positioned(
              bottom: 20,
              right: 20,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: isLocked ? Colors.grey : color,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  isLocked ? Icons.lock : Icons.arrow_forward,
                  color: Colors.white,
                  size: 24,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}